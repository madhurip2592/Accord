const items = document.querySelectorAll(".accordion a");

function toggleAccordion(){
  this.classList.toggle('active');
  this.nextElementSibling.classList.toggle('active');
}

items.forEach(item => item.addEventListener('click', toggleAccordion));

var fa = document.getElementsByClassName(".fa")


$('')

function hide(){
  // fa[1].style.display = "none";

  confirm.log(fa[1])
}